AntiCheat - Lightweight anti-cheat for Paper 1.21 (OP alerts only)
=================================================================

This build sends detection alerts ONLY to players with OP status (isOp()).
It does not broadcast to all players and does not auto-kick by default.

Build:
 - Java 17 + Maven
 - mvn -U clean package
 - target/anticheat-1.0.jar
