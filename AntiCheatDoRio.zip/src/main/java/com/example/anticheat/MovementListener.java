package com.example.anticheat;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

public class MovementListener implements Listener {

    private final AntiCheat plugin;
    private final ChecksManager checks;

    public MovementListener(AntiCheat plugin, ChecksManager checks) {
        this.plugin = plugin;
        this.checks = checks;
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();

        // don't check ops or creative
        if (p.isOp() || p.getGameMode().name().equalsIgnoreCase("CREATIVE")) return;

        // horizontal distance moved
        double dx = e.getTo().getX() - e.getFrom().getX();
        double dz = e.getTo().getZ() - e.getFrom().getZ();
        double horizontal = Math.sqrt(dx*dx + dz*dz);

        long now = System.currentTimeMillis();
        long last = checks.lastMoveTime.getOrDefault(p.getUniqueId(), now);
        long delta = now - last;
        checks.lastMoveTime.put(p.getUniqueId(), now);

        checks.checkSpeed(p, horizontal, delta);

        // yaw change check
        checks.checkYawChange(p, e.getTo().getYaw());
    }
}
