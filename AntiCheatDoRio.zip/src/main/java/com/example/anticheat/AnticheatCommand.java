package com.example.anticheat;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class AnticheatCommand implements CommandExecutor {

    private final AntiCheat plugin;

    public AnticheatCommand(AntiCheat plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage("AntiCheat v1.0 - commands: reload, status");
            return true;
        }
        String sub = args[0].toLowerCase();
        if (sub.equals("reload")) {
            plugin.reloadPlugin();
            sender.sendMessage("AntiCheat reloaded.");
            return true;
        } else if (sub.equals("status")) {
            sender.sendMessage("AntiCheat enabled. Broadcast alerts: " + plugin.getACConfig().broadcastAlerts);
            return true;
        }
        return false;
    }
}
