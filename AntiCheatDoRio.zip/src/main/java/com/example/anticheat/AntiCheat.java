package com.example.anticheat;

import org.bukkit.plugin.java.JavaPlugin;

public class AntiCheat extends JavaPlugin {

    private ACConfig config;
    private ChecksManager checksManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.config = new ACConfig(getConfig());
        this.checksManager = new ChecksManager(this, config);

        getServer().getPluginManager().registerEvents(new CombatListener(this, checksManager), this);
        getServer().getPluginManager().registerEvents(new MovementListener(this, checksManager), this);

        this.getCommand("anticheat").setExecutor(new AnticheatCommand(this));

        getLogger().info("AntiCheat enabled (OP alerts only).");
    }

    @Override
    public void onDisable() {
        getLogger().info("AntiCheat disabled.");
    }

    public void reloadPlugin() {
        reloadConfig();
        this.config = new ACConfig(getConfig());
        this.checksManager.setConfig(config);
    }

    public ACConfig getACConfig() {
        return config;
    }
}
