package com.example.anticheat;

import org.bukkit.configuration.Configuration;

public class ACConfig {

    public final boolean broadcastAlerts;
    public final int hitsPer2s;
    public final double maxReach;
    public final double maxSpeed;
    public final double maxYawChange;
    public final boolean autoKick;
    public final boolean autoBan;

    public ACConfig(Configuration cfg) {
        this.broadcastAlerts = cfg.getBoolean("alerts.broadcast", false);
        this.hitsPer2s = cfg.getInt("thresholds.hits_per_2s", 8);
        this.maxReach = cfg.getDouble("thresholds.max_reach", 4.5);
        this.maxSpeed = cfg.getDouble("thresholds.max_speed", 0.7);
        this.maxYawChange = cfg.getDouble("thresholds.max_vl_yaw_change", 120.0);
        this.autoKick = cfg.getBoolean("auto_action.kick", false);
        this.autoBan = cfg.getBoolean("auto_action.ban", false);
    }
}
