package com.example.anticheat;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ChecksManager {

    private final AntiCheat plugin;
    private ACConfig config;

    // tracking hits per player
    final Map<UUID, Integer> hitCount = new HashMap<>();
    // tracking last locations and yaw
    final Map<UUID, Long> lastMoveTime = new HashMap<>();
    final Map<UUID, Double> lastYaw = new HashMap<>();

    public ChecksManager(AntiCheat plugin, ACConfig config) {
        this.plugin = plugin;
        this.config = config;
        // schedule periodic reset of hit counters every 2s
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            synchronized (hitCount) {
                hitCount.clear();
            }
        }, 0L, 40L);
    }

    public void setConfig(ACConfig cfg) {
        this.config = cfg;
    }

    public void recordHit(Player p) {
        UUID id = p.getUniqueId();
        hitCount.put(id, hitCount.getOrDefault(id, 0) + 1);
        int hits = hitCount.get(id);
        if (hits > config.hitsPer2s) {
            flagPlayer(p, "High hit rate: " + hits + " hits/2s", p.getLocation());
        }
    }

    public void checkReach(Player attacker, Player target, double distance) {
        if (distance > config.maxReach) {
            flagPlayer(attacker, String.format("Reach too far: %.2f blocks", distance), attacker.getLocation());
        }
    }

    public void checkSpeed(org.bukkit.entity.Player p, double distance, long deltaMs) {
        if (deltaMs <= 0) return;
        double speed = (distance / (deltaMs / 1000.0)); // blocks per second
        if (speed > config.maxSpeed * 20) {
            flagPlayer(p, String.format("Speed suspicious: %.2f b/s", speed), p.getLocation());
        }
    }

    public void checkYawChange(Player p, double yaw) {
        Double last = lastYaw.get(p.getUniqueId());
        if (last != null) {
            double diff = Math.abs(normalizeYaw(yaw - last));
            if (diff > config.maxYawChange) {
                flagPlayer(p, String.format("Yaw change too big: %.2f", diff), p.getLocation());
            }
        }
        lastYaw.put(p.getUniqueId(), yaw);
    }

    private double normalizeYaw(double yaw) {
        while (yaw > 180) yaw -= 360;
        while (yaw < -180) yaw += 360;
        return yaw;
    }

    private void flagPlayer(Player p, String reason, Location loc) {
        String msg = "[AntiCheat] " + p.getName() + " flagged: " + reason + " at " +
                String.format("(%.1f, %.1f, %.1f)", loc.getX(), loc.getY(), loc.getZ());
        plugin.getLogger().warning(msg);
        // Send only to OPs
        Bukkit.getOnlinePlayers().forEach(pl -> {
            if (pl.isOp()) {
                pl.sendMessage("§c" + msg);
            }
        });
        // no broadcast to all players
        if (config.autoKick) {
            p.kickPlayer("Kicked by AntiCheat: " + reason);
        }
        if (config.autoBan) {
            Bukkit.getBanList(org.bukkit.BanList.Type.NAME).addBan(p.getName(), "Banned by AntiCheat: " + reason, null, "AntiCheat");
            p.kickPlayer("Banned by AntiCheat: " + reason);
        }
    }
}
