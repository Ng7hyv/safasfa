package com.example.anticheat;

import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class CombatListener implements Listener {

    private final AntiCheat plugin;
    private final ChecksManager checks;

    public CombatListener(AntiCheat plugin, ChecksManager checks) {
        this.plugin = plugin;
        this.checks = checks;
    }

    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player)) return;
        if (!(e.getEntity() instanceof Player)) return;

        Player attacker = (Player) e.getDamager();
        Player target = (Player) e.getEntity();

        if (attacker.getGameMode() == GameMode.CREATIVE) return;

        // record hit rate
        checks.recordHit(attacker);

        // simple reach check: distance from eye location to target's eye location
        double dist = attacker.getEyeLocation().distance(target.getEyeLocation());
        checks.checkReach(attacker, target, dist);

        // check yaw changes
        checks.checkYawChange(attacker, attacker.getLocation().getYaw());
    }
}
